#!/bin/bash
# Create a dsconfig batch script to set up the delegator
THIS_SCRIPT=${0}

searchbasedn="dc=example,dc=com"
pingfedport=9031
pingfedhost_public=localhost
pingfedclientid_ds=pingdirectory
pingfedclientid_app=dadmin
pingfedclient_grant_type=1
authenticate_with_pkce=true
script=delegated-admin.dsconfig
script_proxy=delegated-admin-for-proxy.dsconfig
config=app/config.js
template_common=delegated-admin-template-common.dsconfig
template_ds_or_proxy=delegated-admin-template-ds-or-proxy.dsconfig
template_ds=delegated-admin-template-ds.dsconfig
template_webapp=delegated-admin-template-webapp.dsconfig
template_no_webapp=delegated-admin-template-no-webapp.dsconfig
proxy_in_topology=
webapp_hosted_in_pd=

echo ""
echo "Enter the PingDirectory base DN for Delegated Admin resource data."
read -e -p "Search Base DN [$searchbasedn]:" input
searchbasedn=${input:-$searchbasedn}

echo ""
echo "Enter the public address of the PingFederate server where the app can redirect the user's browser to login."
read -e -p "Public PingFederate hostname or IP address [$pingfedhost_public]:" input
pingfedhost_public=${input:-$pingfedhost_public}

pingfedhost_private=$pingfedhost_public

echo ""
echo "Enter the private address of the PingFederate server reachable by PingDirectory to validate access tokens."
echo "Provide different public and private addresses if the PingFederate Server is not reachable on its public address by PingDirectory."
read -e -p "Private PingFederate hostname or IP address [$pingfedhost_private]:" input
pingfedhost_private=${input:-$pingfedhost_private}

echo ""
echo "Enter the port which your public PingFederate instance is using."
read -e -p "PingFederate port number [$pingfedport]:" input
pingfedport=${input:-$pingfedport}

if [[ $pingfedport == "443" ]]; then
  echo ""
  echo "Since you are using port 443, please answer the following question."
  read -e -p "Does your PingFederate base URL have this port applied to it? [y/n]:" input
  if [[ $input == "n" ]]; then
    pingfedport=""
  fi
fi

pingfedbaseurl="$pingfedhost_private:$pingfedport"
if [ -z "$pingfedport" ]; then
  pingfedbaseurl="$pingfedhost_private"
fi

echo ""
echo "PingDirectory Server must be configured as a client of PingFederate to validate access tokens."
echo "This client configuration requires a Client ID and a Client Secret."
read -e -p "PingFederate Client ID for PingDirectory Server [$pingfedclientid_ds]:" input
pingfedclientid_ds=${input:-$pingfedclientid_ds}

echo ""
while [ -z "$pingfedclientsecret" ]; do
  unset pingfedclientsecret
  prompt="PingFederate Client Secret for PingDirectory Server:"
  while IFS= read -p "$prompt" -r -s -n 1 char
  do
    if [[ $char == $'\0' ]]
    then
        break
    fi
    prompt='*'
    pingfedclientsecret+="$char"
  done
  printf "\n"
done

echo ""
echo "The Delegated Admin application must be configured as a client of PingFederate to obtain access tokens."
echo "This client configuration requires a Client ID but not a Client Secret."
read -e -p "PingFederate Client ID for the application [$pingfedclientid_app]:" input
pingfedclientid_app=${input:-$pingfedclientid_app}

echo ""
echo "What OAuth grant type is the PingFederate client for the Delegated Admin application configured to use?"
echo "  1. Authorization code with PKCE"
echo "  2. Implicit"
read -e -p "OAuth grant type for the application [1]:" input
pingfedclient_grant_type=${input:-$pingfedclient_grant_type}

while [[ ${input} != '' && ${input} != 1 && ${input} != 2 ]]; do
  read -e -p "OAuth grant type for the application [1]:" input
done

pingfedclient_grant_type=${input:-$pingfedclient_grant_type}

if [[ $pingfedclient_grant_type == 2 ]]
then
  authenticate_with_pkce='false'
fi

echo ""
while [[ "${webapp_hosted_in_pd}" != "n" && "${webapp_hosted_in_pd}" != "y" ]]; do
  echo "The Delegated Admin web app can be hosted in PingDirectory or by a third-party web server."
  read -e -p "Will the web app be hosted in PingDirectory? [y/n]:" webapp_hosted_in_pd
done

echo ""
while [[ "${proxy_in_topology}" != "n" && "${proxy_in_topology}" != "y" ]]; do
  read -e -p "Is Delegated Admin being installed in a topology containing PingDirectoryProxy? [y/n]:" proxy_in_topology
done

sed -e "s/PF_HOST = 'localhost'/PF_HOST = '${pingfedhost_public}'/" \
    -e "s/PF_PORT = '9031'/PF_PORT = '${pingfedport}'/" \
    -e "s/DADMIN_CLIENT_ID = 'dadmin'/DADMIN_CLIENT_ID = '${pingfedclientid_app}'/" \
    -e "s/AUTHENTICATE_WITH_PKCE = true/AUTHENTICATE_WITH_PKCE = ${authenticate_with_pkce}/" \
   "app/example.config.js" > ${config}

chmod 600 ${config}

if [[ ${proxy_in_topology} == "y" ]]; then

  sed -e "s/\${searchbasedn}/${searchbasedn}/g" \
      -e "s/\${pingfedbaseurl}/${pingfedbaseurl}/" \
      -e "s/\${pingfedclientid_ds}/${pingfedclientid_ds}/" \
      -e "s/\${pingfedclientsecret}/${pingfedclientsecret}/" \
    ${template_common} > ${script}

  sed -e "s/\${searchbasedn}/${searchbasedn}/g" \
      -e "s/\${pingfedbaseurl}/${pingfedbaseurl}/" \
      -e "s/\${pingfedclientid_ds}/${pingfedclientid_ds}/" \
      -e "s/\${pingfedclientsecret}/${pingfedclientsecret}/" \
    ${template_ds} >> ${script}

  sed -e "s/\${searchbasedn}/${searchbasedn}/g" \
      -e "s/\${pingfedbaseurl}/${pingfedbaseurl}/" \
      -e "s/\${pingfedclientid_ds}/${pingfedclientid_ds}/" \
      -e "s/\${pingfedclientsecret}/${pingfedclientsecret}/" \
    ${template_common} > ${script_proxy}

  sed -e "s/\${searchbasedn}/${searchbasedn}/g" \
      -e "s/\${pingfedbaseurl}/${pingfedbaseurl}/" \
      -e "s/\${pingfedclientid_ds}/${pingfedclientid_ds}/" \
      -e "s/\${pingfedclientsecret}/${pingfedclientsecret}/" \
    ${template_ds_or_proxy} >> ${script_proxy}

  if [[ ${webapp_hosted_in_pd} == "y" ]]; then
    sed -e "s/\${searchbasedn}/${searchbasedn}/g" \
        -e "s/\${pingfedbaseurl}/${pingfedbaseurl}/" \
        -e "s/\${pingfedclientid_ds}/${pingfedclientid_ds}/" \
        -e "s/\${pingfedclientsecret}/${pingfedclientsecret}/" \
      ${template_webapp} >> ${script_proxy}
  else
    sed -e "s/\${searchbasedn}/${searchbasedn}/g" \
        -e "s/\${pingfedbaseurl}/${pingfedbaseurl}/" \
        -e "s/\${pingfedclientid_ds}/${pingfedclientid_ds}/" \
        -e "s/\${pingfedclientsecret}/${pingfedclientsecret}/" \
      ${template_no_webapp} >> ${script_proxy}
  fi

  chmod 600 ${script} ${script_proxy}

  echo ""
  echo "A dsconfig batch script for PingDirectoryProxy has been written to ${script_proxy}."
  echo "Apply this first script to every PingDirectoryProxy instance in the topology."
  echo ""
  echo "A dsconfig batch script for PingDirectory has been written to ${script}."
  echo "Apply this second script to every PingDirectory instance in the topology."

else

  sed -e "s/\${searchbasedn}/${searchbasedn}/g" \
      -e "s/\${pingfedbaseurl}/${pingfedbaseurl}/" \
      -e "s/\${pingfedclientid_ds}/${pingfedclientid_ds}/" \
      -e "s/\${pingfedclientsecret}/${pingfedclientsecret}/" \
    ${template_common} > ${script}

  sed -e "s/\${searchbasedn}/${searchbasedn}/g" \
      -e "s/\${pingfedbaseurl}/${pingfedbaseurl}/" \
      -e "s/\${pingfedclientid_ds}/${pingfedclientid_ds}/" \
      -e "s/\${pingfedclientsecret}/${pingfedclientsecret}/" \
    ${template_ds} >> ${script}

  sed -e "s/\${searchbasedn}/${searchbasedn}/g" \
      -e "s/\${pingfedbaseurl}/${pingfedbaseurl}/" \
      -e "s/\${pingfedclientid_ds}/${pingfedclientid_ds}/" \
      -e "s/\${pingfedclientsecret}/${pingfedclientsecret}/" \
    ${template_ds_or_proxy} >> ${script}

  if [[ ${webapp_hosted_in_pd} == "y" ]]; then
    sed -e "s/\${searchbasedn}/${searchbasedn}/g" \
        -e "s/\${pingfedbaseurl}/${pingfedbaseurl}/" \
        -e "s/\${pingfedclientid_ds}/${pingfedclientid_ds}/" \
        -e "s/\${pingfedclientsecret}/${pingfedclientsecret}/" \
      ${template_webapp} >> ${script}
  else
    sed -e "s/\${searchbasedn}/${searchbasedn}/g" \
        -e "s/\${pingfedbaseurl}/${pingfedbaseurl}/" \
        -e "s/\${pingfedclientid_ds}/${pingfedclientid_ds}/" \
        -e "s/\${pingfedclientsecret}/${pingfedclientsecret}/" \
      ${template_no_webapp} >> ${script}
  fi

  chmod 600 ${script}

  echo ""
  echo "A dsconfig batch script has been written to ${script}."
  echo "Apply this script to every PingDirectory instance in the topology."

fi

echo ""
echo "A webapp config file has been written to ${config}."
echo "Please review the contents of these files and make any necessary adjustments."
echo ""
echo "Use dsconfig with the --batch-file option to apply the commands in a batch script to server instances."
echo "See dsconfig --help for further information and an example of applying a batch file."
echo ""
echo "WARNING: Running the batch script requires special consideration in an environment that includes replicated PingDirectory Servers."
echo "         Consult the Delegated Admin Application Guide before proceeding."
echo ""
