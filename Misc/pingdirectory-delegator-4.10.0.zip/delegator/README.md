# PingDirectory Delegated Admin

## Online Documentation

[Support and Community](https://support.pingidentity.com/s/pingdirectory-help)  
Provides access to administration guides, release notes, and downloads, as well as to the Ping Identity Knowledge Base and the Support Community.

To view an administration guide or a set of release notes, click __PingDirectory__ in the __Software__ section, and then click __Documentation__. To view version-specific documents, select the appropriate version from the drop-down list in the navigation panel.